
float add_floats(float a, float b) {
	return a + b;
}




