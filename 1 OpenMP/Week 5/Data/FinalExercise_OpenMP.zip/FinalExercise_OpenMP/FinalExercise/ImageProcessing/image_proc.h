#include "EasyBMP.h"

//int gaussian_blur(BMP InputImage, int r);
//BMP gaussian_blur_par(BMP InputImage, int r);
