#include "omp.h"
#include <iostream>
#include "submit.h"
using namespace std;

void vec_random_norm(float* rand_arr, int n)
{

	Submit_test();
}