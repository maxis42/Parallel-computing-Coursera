#pragma once

float* vec_random(int n,bool normal);
void vec_random_norm(float* rand_arr, int n);
